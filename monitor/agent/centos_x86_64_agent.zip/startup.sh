#!/bin/sh
nohup ./server > /dev/null 2>&1 &
echo "start server success ~"
